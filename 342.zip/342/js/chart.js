var chart;
		var legend;

		var chartData = [{
				country: "Jquery",
				value: 4000
			},
			{
				country: "HTML5",
				value: 10000
			},
			{
				country: "Photoshop",
				value: 2000
			},
			{
				country: "PHP",
				value: 500
			},
			{
				country: "Bootstrap",
				value: 2500
			},
			{
				country: "CSS3",
				value: 200
			}
		];

		AmCharts.ready(function () {
			// PIE CHART
			chart = new AmCharts.AmPieChart();
			chart.dataProvider = chartData;
			chart.titleField = "country";
			chart.valueField = "value";
			chart.outlineColor = "";
			chart.outlineAlpha = 0.8;
			chart.outlineThickness = 2;
			// this makes the chart 3D
			chart.depth3D = 20;
			chart.angle = 30;

			// WRITE
			chart.write("chartdiv");
		});